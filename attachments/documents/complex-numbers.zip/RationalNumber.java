/* File name: RationalNumber
 * TA: Bonnie
 * Name: Alex Mai
 * Lab Session: TR
 */

public class RationalNumber {
	
	private int numerator, denominator;
	
	//Core constructors
	public RationalNumber (int numerator, int denominator)
	{
		//Making sure that denominator is never 0
		if(denominator == 0)
		{
			denominator = 1;
		}
		
		//this operation knowledge taken from Source 1 in README
		this.numerator = numerator;
		this.denominator = denominator;
	}
	
	public void setNumerator(int numerator)
	{
		this.numerator = numerator;
	}
	public void setDenominator(int denominator)
	{
		this.denominator = denominator;
	}
	
	//return numerator
	public int getNumerator()
	{
		return numerator;
	}
	
	//return denominator
	public int getDenominator()
	{
		return denominator;
	}
	
	//Adding rational numbers in static method
	//Equations on how to add taken from Source 2 in README
	public static RationalNumber addition(RationalNumber num1, RationalNumber num2)
	{
		int nNumerator = 0;
		int nDenominator = 0;
		
		if (num1.denominator % num2.denominator == 0 && num1.denominator >= num2.denominator)
		{
			nNumerator = num1.numerator + num2.numerator * (num1.denominator / num2.denominator);
			nDenominator = num1.denominator;
		}
		else if (num2.denominator % num1.denominator == 0 && num1.denominator <= num2.denominator)
		{
			nNumerator = num1.numerator * (num2.denominator / num1.denominator) + num2.numerator;
			nDenominator = num2.denominator;
		}
		else
		{
			nNumerator = (num1.numerator * num2.denominator) + (num2.numerator * num1.denominator);
			nDenominator = (num1.denominator * num2.denominator);
		}
		
		RationalNumber solution = new RationalNumber(nNumerator, nDenominator);
		return solution;
	}
	
	//Adding in dynamic method
	//Equations taken from Source 2 in README
	public RationalNumber addition(RationalNumber num)
	{
		int nNumerator = 0;
		int nDenominator = 0;
		
		if (this.denominator % num.denominator == 0 && this.denominator >= num.denominator)
		{
			nNumerator = this.numerator + num.numerator * (this.denominator / num.denominator);
			nDenominator = this.denominator;
		}
		else if (num.denominator % this.denominator == 0 && num.denominator >= this.denominator)
		{
			nNumerator = this.numerator * (num.denominator / this.denominator) + num.numerator;
			nDenominator = num.denominator;
		}
		else
		{
			nNumerator = (this.numerator * num.denominator) + (num.numerator * this.denominator);
			nDenominator = (this.denominator * num.denominator);
		}
		
		RationalNumber solution = new RationalNumber (nNumerator, nDenominator);
		return solution;
	}
	
	//Subtracting in static method
	//Equations taken from Source 2 in README
	public static RationalNumber subtraction(RationalNumber num1, RationalNumber num2)
	{
		int nNumerator = 0;
		int nDenominator = 0;
		
		if (num1.denominator % num2.denominator == 0 && num1.denominator >= num2.denominator) 
		{
            nNumerator = num1.numerator - num2.numerator * (num1.denominator / num2.denominator);
            nDenominator = num1.denominator;
        } 
		else if (num2.denominator % num1.denominator == 0 && num2.denominator >= num1.denominator) 
		{
            nNumerator = num1.numerator * (num2.denominator / num1.denominator) - num2.numerator;
            nDenominator = num2.denominator;
        } 
		else 
		{
            nNumerator = (num1.numerator * num2.denominator) - (num2.numerator * num1.denominator);
            nDenominator = (num1.denominator * num2.denominator);
        }
        
		RationalNumber solution = new RationalNumber(nNumerator, nDenominator);
        return solution;
	}
	
	//Subtracting in dynamic method
	//Equations taken from Source 2 in README
	public RationalNumber subtraction(RationalNumber num) 
	{
        int nNumerator = 0;
        int nDenominator = 0;
        if (this.denominator % num.denominator == 0 && this.denominator >= num.denominator) 
        {
            nNumerator = this.numerator - num.numerator * (this.denominator / num.denominator);
            nDenominator = this.denominator;
        } 
        else if (num.denominator % this.denominator == 0 && num.denominator >= this.denominator) 
        {
            nNumerator = this.numerator * (num.denominator / this.denominator) - num.numerator;
            nDenominator = this.denominator * (num.denominator / this.denominator);
        } 
        else 
        {
            nNumerator = (this.numerator * num.denominator) - (num.numerator * this.denominator);
            nDenominator = (this.denominator * num.denominator);
        }
       
        RationalNumber solution = new RationalNumber(nNumerator, nDenominator);
        return solution;
    }

	//Multiplying in static method
	public static RationalNumber multiplication(RationalNumber num1, RationalNumber num2)
	{
		int nNumerator = num1.numerator * num2.numerator;
		int nDenominator = num1.denominator * num2.denominator;
		
		RationalNumber solution = new RationalNumber(nNumerator, nDenominator);
		return solution;
	}
	
	//Multiplying in dynamic method
	public RationalNumber multiplication(RationalNumber num)
	{
		int nNumerator = this.numerator * num.numerator;
		int nDenominator = this.denominator * num.denominator;
		
		RationalNumber solution = new RationalNumber(nNumerator, nDenominator);
		return solution;
	}
	
	//Dividing in static method
	public static RationalNumber division (RationalNumber num1, RationalNumber num2)
	{
		int nNumerator = num1.numerator * num2.denominator;
		int nDenominator = num1.denominator * num1.numerator;
		
		RationalNumber solution = new RationalNumber (nNumerator, nDenominator);
		return solution;
	}
	//Dividing in dynamic method
	public RationalNumber division(RationalNumber num)
	{
		int nNumerator = this.numerator * num.denominator;
        int nDenominator = this.denominator * num.numerator;
        
        RationalNumber solution = new RationalNumber(nNumerator, nDenominator);
        return solution;
	}
	
	//Boolean testing equality and outputting true or false static method
	public static boolean equals(RationalNumber num1, RationalNumber num2)
	{
		if ( (double) num1.numerator / num1.denominator == (double) num2.numerator / num2.denominator)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	//Boolean testing equality and outputting true or false
	public boolean equals(RationalNumber num)
	{
		return (numerator == num.getNumerator() && denominator == num.getDenominator());
	}

	//CompareTo Method
	public int compareTo(RationalNumber num1, RationalNumber num2)
	{
		if((double) num1.numerator / num1.denominator < (double) num2.numerator / num2.denominator)
		{
			return (-1);
		}
		else if ((double) num1.numerator / num1.denominator == (double) num2.numerator / num2.denominator){
			return (0);
		}
		else
		{
			return (1);
		}
	}
	
	//Returns rational number as a string
	public String toString()
	{
		//Making sure that only the numerator takes on negative values
		if ((numerator > 0 && denominator < 0) || (numerator < 0 && denominator < 0)) 
		{
	            numerator = numerator * -1;
	            denominator = denominator * -1;
	        }
	        if (numerator == 0 || denominator == 0) 
	        {
	            return "0";
	        }
	        else 
	        {
	            return numerator + "/" + denominator;
	        }
	}
}
