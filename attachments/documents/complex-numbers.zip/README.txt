Name: Alex Mai
Lab TA: Bonnie
Lab Session: TR
Project 01

For Rational Numbers

1. I first started my class with declaring two private instance variables. Then I wrote my constructor that takes on the parameters of numerator and denominator. Immediately inside the constructor, I made sure that the denominator will never be 0 because it will yield an error; so to solve that, I made an if statement that changed denominator from 0 to 1. Then I defined my mutators and accessors. After that, I created static methods and dynamic methods for the arithmetic equations. For the dynamic methods, since I could only put one variable as the parameter, I utilized the “this” operation to call my instance variables directly. After each arithmetic method, I return a new object called solution that takes on the parameters of nNumerator and nDenominator. As for the boolean method, it returns true or false based off of whether or not both fraction inputs are equivalent that is tested through an if-else statement. For the CompareTo method, I utilized if, else-if, and else statements to compare whether or not the two fraction inputs are the same. But of course, I had to parse them into doubles first because the computer can’t compare numbers when they are strings. Finally, I created a toString method that returns the computed methods in the format a fractions numerator / denominator. But in my test file, I import the scanner and JFileChooser. It prompts the user for the file, initializes the scanner, and then begins a while loop. In the while loop, I take the string line that’s scanned and create arrays that split both the commas and forward slashes. After that, I parse the strings as integer numerators and denominators of each line and create two new objects, one representing the left side of the fractions and one on the right, utilizing my RationalNumber class. I print them out using the println command and by inserting commas in-between.

2. To run program, extract all files onto the desktop. Open Terminal or Command Prompt, type in cd desktop, javac RationalNumber.java ComplexNumber.java Project1Test.java , java Project1Test . It will prompt the user for two files, the first one should be of rational numbers and the second for complex numbers. After selecting the file, it will print out 6 things, each following a comma. They are in order of: sum,difference,product,quotient,equals(true/false),compareTo(-1 for less than, 0 for equal, and 1 for greater than).

3. I have attached a text file called Rational Test Case.txt for the test cases that I edited. They are:

2/3,4/5
-1/6,2/4
1/1,1/1
3/3,3/3

SAMPLE OUTPUT:
You chose to open this file: Rational Test Case.txt
22/15,-2/15,8/15,10/12,false,-1
8/24,-16/24,-2/24,-4/12,false,-1
2/1,0,1/1,1/1,true,0
6/3,0,9/9,9/9,true,0

Sources that I used for Rational Numbers:
1. http://docs.oracle.com/javase/tutorial/java/javaOO/thiskey.html
2. http://www.mathsisfun.com/algebra/rational-numbers-operations.html

For Complex Numbers

1. I first started by importing DecimalFormat because I knew that I would have to format decimals later in the program. I declared my class and created two instance variables, one called real and another called imaginary. Then I created a constructor that takes on two doubles as parameters. After that, I created my accessors and mutators, along with my toString method. When I tested the program, I got really long decimal places for my division output, so I utilized the DecimalFormat to shorten all of the print outs to have three decimals places max. Since DecimalFormat is for strings only, I had to use Double.valueOf command in order to convert my values of real and imaginary back into doubles. After the toString method, I created both static and dynamic methods for the arithmetic. For those, they return an object called solution. In the division methods, I included if statements that checked to see if there would be division by 0; if it were to occur, then I wrote that 0.0 would be returned instead of an error. After that I made two separate methods, one that calculates for the distance of a vector and another for the angle of a vector. I utilized the Math.toDegrees command because Math.atan returned radians, which is consistent with the sample output that was given to us. Then in the main method in Project1Test class, I used the JFileChooser again and this time after splitting the commas, I used the replaceAll command to replace the opening parentheses and closing parentheses all at once. Then I parsed the strings into doubles and created two new objects utilizing the ComplexNumber class and printed my methods out.

2. To run program, extract all files onto the desktop. Open Terminal or Command Prompt, type in cd desktop, javac RationalNumber.java ComplexNumber.java Project1Test.java , java Project1Test . It will prompt the user for two files, the first one should be of rational numbers and the second for complex numbers. After selecting the file, it will print out 5 things, each nested in parentheses and following a comma. They are in order of: sum(real;imaginary),difference(real;imaginary),product(real;imaginary),quotient(real;imaginary),polar(distance;angle).

3. I have attached a text file that’s called Complex Test Case.txt. It has the same inputs as the sample inputs given to us.

They are as followed:

(2;-3),(1;1)
(3;4),(2;5)

SAMPLE OUTPUT
You chose to open this file: Complex Test Case.txt
(3.0;-2.0),(1.0;-4.0),(5.0;-1.0),(-0.5;-2.5),(3.606;-56.31)
(5.0;9.0),(1.0;-1.0),(-14.0;23.0),(0.897;-0.241),(5;53.13)

Sources that I used for Complex Numbers:
1. http://www.java-forums.org/advanced-java/4130-rounding-double-two-decimal-places.html
2. http://www.mathportal.org/formulas/algebra/complex.php
3. http://www.mathsisfun.com/algebra/complex-plane.html
4. http://stackoverflow.com/questions/15726914/remove-parenthesis-from-string-using-java-regex