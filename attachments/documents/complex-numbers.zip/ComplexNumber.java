/* File name: ComplexNumber
 * TA: Bonnie
 * Name: Alex Mai
 * Lab Session: TR
 */

import java.text.DecimalFormat;

public class ComplexNumber 
{
	private double real;
	private double imaginary;

	//Object creation
	public ComplexNumber(double real, double imaginary)
	{
		this.real= real;
		this.imaginary = imaginary;
	}
	
	//Mutators
	public void setreal(double real)
	{
		this.real = real;
	}
	public void setimaginary(double imaginary)
	{
		this.imaginary = imaginary;
	}
	
	//return real and imaginary
	public double getreal()
	{
		return real;
	}
	public double getimaginary()
	{
		return imaginary;
	}

	//Changing objects to string
	public String toString()
	{
		DecimalFormat fmt = new DecimalFormat("#.###");

		if (real == 0 && imaginary == 0)
		{
			return "(0;0)";
		}
		else
		{
			//Knowledge of how to use Double.valueOf taken from Source 1 in README
			return "("+Double.valueOf(fmt.format(real))+";"+Double.valueOf(fmt.format(imaginary))+")";
		}
	}

	//Addition in static method
	public static ComplexNumber addition(ComplexNumber a, ComplexNumber b)
	{
		double nReal = a.real + b.real;
		double nImaginary = a.imaginary + b.imaginary;
		
		ComplexNumber solution = new ComplexNumber(nReal, nImaginary);
		return solution;
	}
	
	//Addition in dynamic method
	public ComplexNumber addition(ComplexNumber a)
	{
		double nReal = this.real + a.real;
		double nImaginary = this.imaginary + a.imaginary;
		
		ComplexNumber solution = new ComplexNumber(nReal, nImaginary);
		return solution;	
	}

	//Subtraction in static method
	public static ComplexNumber subtraction(ComplexNumber a, ComplexNumber b)
	{
		double nReal = a.real - b.real;
		double nImaginary = a.imaginary - b.imaginary;
		
		ComplexNumber solution = new ComplexNumber(nReal, nImaginary);
		return solution;
	}
	
	//Subtraction in dynamic method
	public ComplexNumber subtraction(ComplexNumber a)
	{
		double nReal = this.real - a.real;
		double nImaginary = this.imaginary - a.imaginary;
		
		ComplexNumber solution = new ComplexNumber(nReal, nImaginary);
		return solution;
	}
	
	//Multiplication in static method
	//Knowledge of multiplying complex numbers & equations taken from Source 2 in README
	public static ComplexNumber multiplication(ComplexNumber a, ComplexNumber b)
	{
		double nReal = a.real * b.real - a.imaginary * b.imaginary;
		double nImaginary = a.real * b.imaginary + a.imaginary * b.real;
		
		ComplexNumber solution = new ComplexNumber(nReal, nImaginary);
		return solution;
	}

	//Multiplication in dynamic method
	//Knowledge of multiplying complex numbers & equations taken from Source 2 in README
	public ComplexNumber multiplication(ComplexNumber a)
	{
		double nReal = this.real * a.real - this.imaginary * a.imaginary;
		double nImaginary = this.real * a.imaginary + this.imaginary * a.real;
		
		ComplexNumber solution = new ComplexNumber(nReal, nImaginary);
		return solution;
	}

	//Division in static method
	//Knowledge of dividing complex numbers & equations taken from Source 2 in README
	public static ComplexNumber division(ComplexNumber a, ComplexNumber b)
	{
		//Calculates the real part of the expression
		double numerator = (a.real * b.real) + (a.imaginary * b.imaginary);
		double denominator = (b.real * b.real) + (b.imaginary * b.imaginary);
		
		//Calculates the imaginary part of the expression
		double numerator1 = (a.imaginary * b.real) - (a.real * b.imaginary);
		double denominator1 = (b.real * b.real) + (b.imaginary * b.imaginary);
		
		//Check to see if division equals 0
		if (numerator != 0 && denominator != 0 || numerator1 != 0 && denominator1 != 0)
		{
			double nReal = numerator / denominator;
			double nImaginary = numerator1 / denominator1;
			
			ComplexNumber solution = new ComplexNumber(nReal, nImaginary);
			return solution;
		}
		else
		{
			double nReal = 0.0;
			double nImaginary = 0.0;
			
			ComplexNumber solution = new ComplexNumber(nReal, nImaginary);
			return solution;
		} 
	}
	
	//Division in dynamic method
	//Knowledge of dividing complex numbers & equations taken from Source 2 in README
	public ComplexNumber division(ComplexNumber a)
	{
		//Calculates the real part of the expression
		double numerator = (this.real * a.real) + (a.imaginary * this.imaginary);
		double denominator = (a.real * a.real) + (a.imaginary * a.imaginary);
		
		//Calculates the imaginary part of the expression
		double numerator1 = (this.imaginary * a.real) - (this.real * a.imaginary);
		double denominator1 = (a.real * a.real) + (a.imaginary * a.imaginary);
		
		//Check to see if division equals 0
		if (numerator != 0 && denominator != 0 || numerator1 != 0 && denominator1 != 0)
		{
			double nReal = numerator / denominator;
			double nImaginary = numerator1 / denominator1;
			
			ComplexNumber solution = new ComplexNumber(nReal, nImaginary);
			return solution;
		}
		else
		{
			double nReal = 0.0;
			double nImaginary = 0.0;
			
			ComplexNumber solution = new ComplexNumber(nReal, nImaginary);
			return solution;
		}
	}
	
	//Calculating Distance of vector
	//Knowledge and equations taken from Source 3 in README
	public String distance()
	{
		//doubles will have three decimal places for accuracy
		DecimalFormat fmt = new DecimalFormat("#.###");
		
		//Calculates distance using Cartesian to Polar conversion
		double square = Math.pow(real, 2) + Math.pow(imaginary, 2);
        double distance = Math.sqrt(square);

		String solution = fmt.format(distance);
		
		return solution;
	}
	
	//Calculating angle of vector
	//Knowledge and equations taken from Source 3 in README
	public String angle()
	{
		//doubles will have three decimal places for accuracy
		DecimalFormat fmt = new DecimalFormat("#.##");
		
		//Calculating angle using Cartesian to Polar conversion
		double angle = 0.0;
		if (real == 0.0)
		{
			 angle = 90.00;
		}
		else
		{
			angle = Math.toDegrees(Math.atan(imaginary / real));
		}
		String solution = fmt.format(angle);
		
		return solution;
	}
}