/* File name: Project1Test
 * TA: Bonnie
 * Name: Alex Mai
 * Lab Session: TR
 */

import javax.swing.JFileChooser;
import java.util.Scanner;

public class Project1Test {
	//Main method
	public static void main(String[] args) throws Exception
	{
		//Printing out rational numbers
		JFileChooser chooser = new JFileChooser();
		int returnVal = chooser.showOpenDialog(null);
		
		if (returnVal == JFileChooser.APPROVE_OPTION)
		{
			System.out.println("You chose to open this file: " + chooser.getSelectedFile().getName());
			Scanner scan = new Scanner(chooser.getSelectedFile());
			
			while (scan.hasNext())
			{
				String temp = scan.nextLine();
				
				String[] test = temp.split(",");
				String[] slash = test[0].split("/");
				String[] slash1 = test[1].split("/");
				
				int numerator = Integer.parseInt(slash[0]);
				int denominator = Integer.parseInt(slash[1]);
				int numerator1 = Integer.parseInt(slash1[0]);
				int denominator1 = Integer.parseInt(slash1[1]);
				
				RationalNumber print = new RationalNumber(numerator, denominator);
				RationalNumber print1 = new RationalNumber(numerator1, denominator1);
				
				System.out.println(print.addition(print1) + "," + print.subtraction(print1) + "," + print.multiplication(print1) + "," + print.division(print1) + "," + print.equals(print1) + "," + print.compareTo(print, print1));
			}
			scan.close();
		}
		else
		{
			System.out.println("No file selected");
		} 
		
		//Printing out complex numbers
		JFileChooser chooser1 = new JFileChooser();
		int returnVal1 = chooser1.showOpenDialog(null);
		
		if (returnVal1 == JFileChooser.APPROVE_OPTION)
		{
			System.out.println("\nYou chose to open this file: " + chooser1.getSelectedFile().getName());
			Scanner scan = new Scanner(chooser1.getSelectedFile());
			
			while (scan.hasNext())
			{
				String temp = scan.nextLine();
				
				String[] test = temp.split(",");
				
				//ReplaceAll knowledge taken from Source 4 in README
				String replaced = test[0].replaceAll("[()]","");
				String replaced1 = test[1].replaceAll("[()]", "");
				
				String[] semicolon = replaced.split(";");
				String[] semicolon1 = replaced1.split(";");

				double real = Double.parseDouble(semicolon[0]);
				double imaginary = Double.parseDouble(semicolon[1]);
				
				double real1 = Double.parseDouble(semicolon1[0]);
				double imaginary1 = Double.parseDouble(semicolon1[1]);
				
				ComplexNumber print = new ComplexNumber(real, imaginary);
				ComplexNumber print1 = new ComplexNumber(real1, imaginary1);
				
				System.out.println(print.addition(print1) + "," + print.subtraction(print1) + "," + print.multiplication(print1) + "," + print.division(print1) + "," + "(" + print.distance() + ";" + print.angle() + ")");
				
			}
			scan.close();
		}
		else
		{
			System.out.println("No file selected");
		}
	}
}
